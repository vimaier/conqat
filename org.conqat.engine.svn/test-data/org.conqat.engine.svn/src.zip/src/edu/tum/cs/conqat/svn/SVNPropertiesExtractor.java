/*--------------------------------------------------------------------------+
   $Id: SVNPropertiesExtractor.java 24468 2009-10-13 13:05:47Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.svn;

import java.util.HashSet;
import java.util.Set;

import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.wc.SVNClientManager;
import org.tmatesoft.svn.core.wc.SVNPropertyData;
import org.tmatesoft.svn.core.wc.SVNRevision;
import org.tmatesoft.svn.core.wc.SVNWCClient;

import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.traversal.ETargetNodes;
import edu.tum.cs.conqat.commons.traversal.TargetExposedNodeTraversingProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Extracts svn-properties from elements in a file system scope. The property
 * values are annotated at the corresponding elements using the property name as
 * key.
 * <p>
 * The processor issues warning messages for elements that are not under version
 * control.
 * 
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 24468 $
 * @levd.rating GREEN Hash: D3DF9A2CDE618F4AFB3CF8A55D284DD1
 */
@AConQATProcessor(description = "Extracts svn-properties from elements in a file system scope. The property"
		+ "values are annotated at the corresponding elements using the property name as"
		+ "key."
		+ "The processor issues warning messages for elements that are not under version"
		+ "control.")
public class SVNPropertiesExtractor extends
		TargetExposedNodeTraversingProcessorBase<IFileSystemElement> {

	/** Working Copy client used to extract property information */
	private final SVNWCClient wcClient = SVNClientManager.newInstance()
			.getWCClient();

	/** Set of property names that are extracted */
	private final Set<String> propertyNames = new HashSet<String>();

	/** Adds a property name */
	@AConQATParameter(name = "property", description = "Adds a property name", minOccurrences = 1)
	public void addPropertyName(
			@AConQATAttribute(name = "name", description = "Property name") String propertyName) {
		propertyNames.add(propertyName);
	}

	/** Add names of properties to the display list */
	@Override
	protected void setUp(IFileSystemElement root) {
		NodeUtils.addToDisplayList(root, propertyNames);
	}

	/** Returns {@link ETargetNodes#LEAVES}. */
	@Override
	protected ETargetNodes getDefaultTargetNodes() {
		return ETargetNodes.LEAVES;
	}

	/** Extract properties and store them at the element */
	public void visit(IFileSystemElement element) {
		try {
			for (String propertyName : propertyNames) {
				SVNPropertyData property = wcClient.doGetProperty(element
						.getFile(), propertyName, SVNRevision.WORKING,
						SVNRevision.WORKING);

				if (property != null) {
					element.setValue(propertyName, property.getValue());
				}
			}
		} catch (SVNException e) {
			getLogger().warn(
					"Couldn't determine properties for " + element + ": "
							+ e.getMessage());
		}
	}

}
