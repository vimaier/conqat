public class NoByteCode {

    int b;

}
