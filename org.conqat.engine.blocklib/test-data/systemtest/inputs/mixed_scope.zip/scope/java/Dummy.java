public class Dummy {

    int a;

}
