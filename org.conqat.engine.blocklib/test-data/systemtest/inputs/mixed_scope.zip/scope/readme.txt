This is test input containing lots of different file types.
