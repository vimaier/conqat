/*--------------------------------------------------------------------------+
   $Id: StartupServlet.java 32373 2010-12-30 23:14:23Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package org.conqat.engine.codesearch.servlet;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Fieldable;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.SimpleFSDirectory;
import org.conqat.lib.commons.collections.CollectionUtils;
import org.conqat.lib.commons.collections.UnmodifiableSet;
import org.conqat.lib.commons.enums.EnumUtils;
import org.conqat.lib.commons.filesystem.FileSystemUtils;
import org.conqat.lib.scanner.ELanguage;

public class StartupServlet extends HttpServlet {

	private static Logger logger = Logger.getLogger(StartupServlet.class);

	private static StartupServlet INSTANCE;

	private IndexSearcher indexSearcher;

	private final HashSet<String> metrics = new HashSet<String>();

	private int docCount;

	private ELanguage language;

	public static StartupServlet getInstance() {
		return INSTANCE;
	}

	@Override
	public void init() throws ServletException {
		INSTANCE = this;

		File indexDirectory = new File(getInitParameter("index-directory"));
		if (!indexDirectory.isDirectory()) {
			throw new ServletException("Could not find index directory");
		}
		String logFile = getInitParameter("log-file");

		try {
			initLogger(logFile);
		} catch (IOException e) {
			logger.error(e);
			throw new ServletException(e);
		}

		try {
			IndexReader indexReader = IndexReader.open(new SimpleFSDirectory(
					indexDirectory));

			determineMetrics(indexReader);
			determineLanguage(indexReader);
			docCount = indexReader.numDocs();
			indexSearcher = new IndexSearcher(indexReader);
		} catch (IOException e) {
			logger.error(e);
			throw new ServletException(e);
		}

		// try {
		// FileSystemUtils.writeFile(new File("g:/startup.log"), "test123 "
		// + indexDirectoryName + " " + logFile);
		// } catch (IOException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
	}

	private void determineMetrics(IndexReader indexReader)
			throws CorruptIndexException, IOException {
		Document metricDescriptor = indexReader.document(0);

		for (Fieldable field : (List<Fieldable>) metricDescriptor.getFields()) {
			String fieldName = field.name();
			if (!"path".equals(fieldName) && !"language".equals(fieldName)) {
				metrics.add(fieldName);
			}
		}

	}

	private void determineLanguage(IndexReader indexReader) throws IOException {
		Document descriptor = indexReader.document(0);

		String languageString = descriptor.get("language");
		language = EnumUtils.valueOf(ELanguage.class, languageString);

		if (language == null) {
			throw new IOException("Could not determine language.");
		}
	}

	public IndexSearcher getIndexSearcher() {
		return indexSearcher;
	}

	public int getDocCount() {
		return docCount;
	}

	public String getPath(int docNum) {
		try {
			Document doc = indexSearcher.doc(docNum);
			if (doc == null) {
				return "Unknown document";
			}
			return doc.get("path");
		} catch (IOException e) {
			return e.getMessage();
		}
	}

	public UnmodifiableSet<String> getMetrics() {
		return CollectionUtils.asUnmodifiable(metrics);
	}

	private void initLogger(String logFile) throws IOException {
		FileSystemUtils.ensureParentDirectoryExists(new File(logFile));
		Logger.getRootLogger().setLevel(Level.DEBUG);
		BasicConfigurator.configure(new FileAppender(new PatternLayout(
				"%-5p : %m%n"), logFile, false));
		logger.info("Initialized logger.");
	}

	public ELanguage getLanguage() {
		return language;
	}

}
