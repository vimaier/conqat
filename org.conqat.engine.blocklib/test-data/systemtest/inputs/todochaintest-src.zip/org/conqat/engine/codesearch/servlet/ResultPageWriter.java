/*--------------------------------------------------------------------------+
   $Id: ResultPageWriter.java 32087 2010-12-22 21:03:01Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package org.conqat.engine.codesearch.servlet;

import static org.conqat.lib.commons.html.ECSSProperty.BACKGROUND_COLOR;
import static org.conqat.lib.commons.html.ECSSProperty.COLOR;
import static org.conqat.lib.commons.html.ECSSProperty.FONT_WEIGHT;
import static org.conqat.lib.commons.html.ECSSProperty.TEXT_ALIGN;
import static org.conqat.lib.commons.html.ECSSProperty.TEXT_DECORATION;
import static org.conqat.lib.commons.html.EHTMLAttribute.BORDER;
import static org.conqat.lib.commons.html.EHTMLAttribute.COLSPAN;
import static org.conqat.lib.commons.html.EHTMLAttribute.HREF;
import static org.conqat.lib.commons.html.EHTMLAttribute.SRC;
import static org.conqat.lib.commons.html.EHTMLAttribute.STYLE;
import static org.conqat.lib.commons.html.EHTMLAttribute.WIDTH;
import static org.conqat.lib.commons.html.EHTMLElement.A;
import static org.conqat.lib.commons.html.EHTMLElement.DIV;
import static org.conqat.lib.commons.html.EHTMLElement.IMG;
import static org.conqat.lib.commons.html.EHTMLElement.PRE;
import static org.conqat.lib.commons.html.EHTMLElement.SPAN;
import static org.conqat.lib.commons.html.EHTMLElement.TABLE;
import static org.conqat.lib.commons.html.EHTMLElement.TD;
import static org.conqat.lib.commons.html.EHTMLElement.TH;
import static org.conqat.lib.commons.html.EHTMLElement.TR;
import static org.conqat.engine.codesearch.servlet.CSSMananger.CODE;
import static org.conqat.engine.codesearch.servlet.CSSMananger.DEFAULT_FONT;
import static org.conqat.engine.codesearch.servlet.CSSMananger.INLINED_IMAGE;
import static org.conqat.engine.codesearch.servlet.CSSMananger.LARGE_BOLD_FONT;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.queryParser.ParseException;

import org.conqat.lib.commons.assertion.CCSMAssert;
import org.conqat.lib.commons.color.ECCSMColor;
import org.conqat.lib.commons.html.CSSDeclarationBlock;
import org.conqat.lib.commons.html.EHTMLAttribute;
import org.conqat.lib.commons.string.StringUtils;
import org.conqat.engine.codesearch.Result;
import org.conqat.engine.codesearch.SearchEngine;

public class ResultPageWriter extends PageWriterBase {

	public static final int NUM_OF_RESULTS = 25;

	private static final CSSDeclarationBlock LIGHT_GRAY_CELL = new CSSDeclarationBlock(
			BACKGROUND_COLOR, "#F7F7F7");
	private static final CSSDeclarationBlock TABLE_HEADER = new CSSDeclarationBlock(
			BACKGROUND_COLOR, ECCSMColor.DARK_GRAY.getHTMLColorCode(), COLOR,
			"white", FONT_WEIGHT, "bold", TEXT_ALIGN, "left");

	private static final CSSDeclarationBlock LIGHT_BLUE_CELL = new CSSDeclarationBlock(
			BACKGROUND_COLOR, ECCSMColor.LIGHT_BLUE.getHTMLColorCode());
	private static final CSSDeclarationBlock BLUE_CELL = new CSSDeclarationBlock(
			BACKGROUND_COLOR, ECCSMColor.BLUE.getHTMLColorCode(), COLOR,
			"white");

	private static Logger logger = Logger.getLogger(ResultPageWriter.class);
	private final SearchEngine searchEngine;
	private final String queryString;
	private final int from;
	private final int to;

	private final String metric;

	private final boolean useSimilarity;

	private final StartupServlet startupServlet = StartupServlet.getInstance();

	public ResultPageWriter(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		super("Search Results", request, response);
		searchEngine = new SearchEngine();
		queryString = request.getParameter("query");
		from = parseInt(request.getParameter("from"), 0);
		to = parseInt(request.getParameter("to"), 25);
		metric = determineMetric(request.getParameter("metric"));
		useSimilarity = parseBoolean(request.getParameter("similarity"), true);
	}

	private String determineMetric(String metric) {
		if (StringUtils.isEmpty(metric)) {
			return null;
		}
		if (!startupServlet.getMetrics().contains(metric)) {
			logger.warn("Unknown metric: " + metric);
			return null;
		}
		return metric;
	}

	private boolean parseBoolean(String string, boolean defaultValue) {
		if (StringUtils.isEmpty(string)) {
			return defaultValue;
		}
		return Boolean.parseBoolean(string);
	}

	private String getString(String string, String defaultValue) {
		if (StringUtils.isEmpty(string)) {
			return defaultValue;
		}
		return string;
	}

	private int parseInt(String string, int defaultValue) {
		if (StringUtils.isEmpty(string)) {
			return defaultValue;
		}
		try {
			return Integer.parseInt(string);
		} catch (NumberFormatException ex) {
			return defaultValue;
		}
	}

	@Override
	protected void writePageBody() {

		writeHeader();

		try {
			SearchResult searchResult = searchEngine.search(queryString, from,
					to, metric, useSimilarity);
			writeHits(searchResult);
			if (searchResult.getHitCount() > 25) {
				writeNavigation(searchResult);
			}
		} catch (IOException e) {
			logger.error(e);
			return;
		} catch (ParseException e) {
			logger.error(e);
			return;
		}

	}

	private void writeNavigation(SearchResult searchResult) {
		openElement(DIV, STYLE, new CSSDeclarationBlock(TEXT_ALIGN, "center",
				BACKGROUND_COLOR, ECCSMColor.LIGHT_GRAY.getHTMLColorCode()));
		setSuppressLineBreaks(true);
		if (from > 0) {
			openElement(A, HREF, createURL(from - NUM_OF_RESULTS, to
					- NUM_OF_RESULTS));
			addClosedElement(IMG, SRC, "left_arrow.gif", STYLE, INLINED_IMAGE);
			closeElement(A);
		} else {
			addClosedElement(IMG, SRC, "left_arrow_disabled.gif", STYLE,
					INLINED_IMAGE);
		}
		setSuppressLineBreaks(false);
		for (int i = 0; i < searchResult.getHitCount(); i += NUM_OF_RESULTS) {
			writeNavigationLink(i / NUM_OF_RESULTS + 1, i, i + NUM_OF_RESULTS);
		}
		setSuppressLineBreaks(true);
		if (to < searchResult.getHitCount()) {
			openElement(A, HREF, createURL(from + NUM_OF_RESULTS, to
					+ NUM_OF_RESULTS));
			addClosedElement(IMG, SRC, "right_arrow.gif", STYLE, INLINED_IMAGE);
			closeElement(A);
		} else {
			addClosedElement(IMG, SRC, "right_arrow_disabled.gif", STYLE,
					INLINED_IMAGE);
		}
		setSuppressLineBreaks(false);
		closeElement(DIV);
	}

	private void writeNavigationLink(int pageNum, int from, int to) {
		if (this.from == from && this.to == to) {
			addClosedTextElement(SPAN, String.valueOf(pageNum), STYLE,
					new CSSDeclarationBlock(COLOR, ECCSMColor.DARK_GRAY
							.getHTMLColorCode()));
			return;
		}

		String link = createURL(from, to);
		addClosedTextElement(A, String.valueOf(pageNum), HREF, link, STYLE,
				new CSSDeclarationBlock(COLOR, ECCSMColor.BLUE
						.getHTMLColorCode(), TEXT_DECORATION, "none"));
	}

	private boolean isCurrentPage(int from, int to) {
		return this.from == from && this.to == to;
	}

	private String createURL(int from, int to) {
		return createURL("result", "query", queryString, "from", from, "to",
				to, "metric", metric, "similarity", useSimilarity);
	}

	private String createURL(String target, Object... parameters) {
		if (parameters.length % 2 != 0) {
			throw new IllegalArgumentException(
					"Even number of parameters expected");
		}
		StringBuilder result = new StringBuilder();
		result.append(target).append("?");

		for (int i = 0; i < parameters.length; i += 2) {
			if (!(parameters[i] instanceof String)) {
				throw new IllegalArgumentException(
						"Parameter must be of type string");
			}
			result.append(encode(parameters[i]));
			result.append("=");
			result.append(encode(parameters[i + 1]));

			if (i < parameters.length - 2) {
				result.append("&");
			}
		}

		return result.toString();
	}

	private String encode(Object obj) {
		if (obj == null) {
			return null;
		}
		try {
			return URLEncoder.encode(obj.toString(), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			CCSMAssert.fail("Unknown encoding");
			return null;
		}
	}

	private void writeHeader() {
		openElement(TABLE, BORDER, 0, EHTMLAttribute.WIDTH, "100%");
		openElement(TR);
		openElement(TD, EHTMLAttribute.WIDTH, "100%", STYLE, LARGE_BOLD_FONT);
		addText("Search for ");
		addRawString("&laquo;");
		addText(queryString);
		addRawString("&raquo;");
		closeElement(TD);
		openElement(TD);
		addClosedElement(IMG, SRC, "codesearch_logo.png");
		closeElement(TD);
		closeElement(TR);
		closeElement(TABLE);

	}

	private void writeHits(SearchResult searchResult)
			throws CorruptIndexException, IOException, ParseException {

		openElement(DIV, STYLE, new CSSDeclarationBlock().setMargin("6px"));

		if (searchResult.getHitCount() == 0) {
			addText("Query returned no results.");
			closeElement(DIV);
			return;
		}

		List<Result> hits = searchResult.getResults();

		addText("Found " + searchResult.getHitCount() + " documents in "
				+ searchResult.getTime() + "ms.");
		closeElement(DIV);

		openElement(TABLE, STYLE, DEFAULT_FONT, WIDTH, "100%");

		openElement(TR);
		addClosedTextElement(TH, "#", STYLE, TABLE_HEADER);
		addClosedTextElement(TH, "Score", STYLE, TABLE_HEADER);

		if (metric != null) {
			addClosedTextElement(TH, metric, STYLE, TABLE_HEADER);
		}

		addClosedTextElement(TH, "Path", STYLE, TABLE_HEADER);
		closeElement(TR);

		for (Result result : hits) {
			openElement(TR);
			openElement(TD, STYLE, BLUE_CELL);
			addText(StringUtils.format(result.getResultNo()));
			closeElement(TD);
			openElement(TD, STYLE, BLUE_CELL);
			addText(StringUtils.format(result.getScore()));
			closeElement(TD);

			if (metric != null) {
				openElement(TD, STYLE, BLUE_CELL);
				addText(result.getMetricValue());
				closeElement(TD);
			}

			openElement(TD, STYLE, BLUE_CELL);

			// addText(result.getPath());
			addClosedTextElement(A, result.getPath(), HREF, "browser?docNum="
					+ result.getDocNum() + "&query=" + queryString, STYLE,
					new CSSDeclarationBlock(COLOR, "white", TEXT_DECORATION,
							"none"));
			closeElement(TD);

			openElement(TR);
			addClosedTextElement(TD, "");

			int colspan;

			if (metric == null) {
				colspan = 2;
			} else {
				colspan = 3;
			}
			openElement(TD, COLSPAN, colspan);
			openElement(PRE, STYLE, CODE);
			addRawString(result.getPreview());
			closeElement(PRE);
			closeElement(TD);
			closeElement(TR);

			closeElement(TR);
		}
		closeElement(TABLE);
	}

}
