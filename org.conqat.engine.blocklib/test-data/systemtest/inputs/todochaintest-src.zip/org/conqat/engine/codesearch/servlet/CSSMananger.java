/*--------------------------------------------------------------------------+
   $Id: CSSMananger.java 32087 2010-12-22 21:03:01Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package org.conqat.engine.codesearch.servlet;

import static org.conqat.lib.commons.color.ECCSMColor.DARK_GRAY;
import static org.conqat.lib.commons.color.ECCSMColor.LIGHT_GRAY;
import static org.conqat.lib.commons.html.ECSSProperty.BACKGROUND_COLOR;
import static org.conqat.lib.commons.html.ECSSProperty.COLOR;
import static org.conqat.lib.commons.html.ECSSProperty.CURSOR;
import static org.conqat.lib.commons.html.ECSSProperty.DISPLAY;
import static org.conqat.lib.commons.html.ECSSProperty.FILTER;
import static org.conqat.lib.commons.html.ECSSProperty.FONT_FAMILY;
import static org.conqat.lib.commons.html.ECSSProperty.FONT_SIZE;
import static org.conqat.lib.commons.html.ECSSProperty.FONT_WEIGHT;
import static org.conqat.lib.commons.html.ECSSProperty.LINE_HEIGHT;
import static org.conqat.lib.commons.html.ECSSProperty.MARGIN_RIGHT;
import static org.conqat.lib.commons.html.ECSSProperty.OPACITY;
import static org.conqat.lib.commons.html.ECSSProperty.TEXT_ALIGN;
import static org.conqat.lib.commons.html.ECSSProperty.TEXT_DECORATION;
import static org.conqat.lib.commons.html.ECSSProperty.VERTICAL_ALIGN;
import static org.conqat.lib.commons.html.ECSSProperty.WHITE_SPACE;
import static org.conqat.lib.commons.html.EHTMLElement.A;
import static org.conqat.lib.commons.html.EHTMLElement.IMG;
import org.conqat.lib.commons.color.ECCSMColor;
import org.conqat.lib.commons.html.CSSDeclarationBlock;
import org.conqat.lib.commons.html.CSSManagerBase;
import org.conqat.lib.commons.html.ECSSPseudoClass;

/**
 * The CSS manager used for ConQATDoc. This class defines a number of basic
 * classes that should be reused in other places. Furthermore it sets the
 * default styles for some HTML elments.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating RED Hash: DCE5885F0C76CFF987D0DCB3CBD375D9
 */
public class CSSMananger extends CSSManagerBase {

	/** Sans-serif font. */
	public static final CSSDeclarationBlock SAN_SERIF_FONT = new CSSDeclarationBlock(
			FONT_FAMILY, "verdana, helvetica, sans-serif");

	/** Default font. */
	public static final CSSDeclarationBlock DEFAULT_FONT = new CSSDeclarationBlock(
			SAN_SERIF_FONT, FONT_SIZE, "13px");

	/** Small font. */
	public static final CSSDeclarationBlock SMALL_FONT = new CSSDeclarationBlock(
			SAN_SERIF_FONT, FONT_SIZE, "10px");

	/** Bold font. */
	public static final CSSDeclarationBlock DEFAULT_FONT_BOLD = new CSSDeclarationBlock(
			DEFAULT_FONT, FONT_WEIGHT, "bold");

	/** Bold font. */
	public static final CSSDeclarationBlock LARGE_BOLD_FONT = new CSSDeclarationBlock(
			DEFAULT_FONT, FONT_WEIGHT, "bold", FONT_SIZE, "26px", COLOR,
			ECCSMColor.BLUE.getHTMLColorCode());

	/** Dark gray border. */
	public static final CSSDeclarationBlock DARK_GRAY_BORDER = new CSSDeclarationBlock()
			.setBorder("1px", "solid", DARK_GRAY.getHTMLColorCode());

	/** Light blue border plus margin. */
	public static final CSSDeclarationBlock LIGHT_BLUE_BORDER = new CSSDeclarationBlock()
			.setBorder("1px", "solid", ECCSMColor.BLUE.getHTMLColorCode())
			.setMargin("8px");

	/** Base class for table cells. */
	private static final CSSDeclarationBlock TABLE_CELL_BASE = new CSSDeclarationBlock(
			SMALL_FONT, TEXT_ALIGN, "left").setMargin("0px").setPadding("2px");

	/** Default table header cell. */
	public static final CSSDeclarationBlock TABLE_HEADER_CELL = new CSSDeclarationBlock(
			TABLE_CELL_BASE, COLOR, "white", BACKGROUND_COLOR, DARK_GRAY
					.getHTMLColorCode(), VERTICAL_ALIGN, "text-bottom",
			FONT_WEIGHT, "bold", WHITE_SPACE, "nowrap");

	/** Default table cell. */
	public static final CSSDeclarationBlock TABLE_CELL = new CSSDeclarationBlock(
			TABLE_CELL_BASE, BACKGROUND_COLOR, LIGHT_GRAY.getHTMLColorCode(),
			VERTICAL_ALIGN, "middle", WHITE_SPACE, "nowrap");

	/** Link in table. */
	public static CSSDeclarationBlock TABLE_LINK = new CSSDeclarationBlock(
			SMALL_FONT, FONT_WEIGHT, "normal", COLOR, "black", TEXT_DECORATION,
			"none");

	/** Link in table head. */
	public static CSSDeclarationBlock TABLE_HEADER_LINK = new CSSDeclarationBlock(
			SMALL_FONT, FONT_WEIGHT, "bold", COLOR, "white", TEXT_DECORATION,
			"none");

	/** Icon in table. */
	public static CSSDeclarationBlock TABLE_ICON = new CSSDeclarationBlock(
			DISPLAY, "inline", VERTICAL_ALIGN, "middle", MARGIN_RIGHT, "6px");

	/** Style for DIVs used in tool-tips. */
	public static final CSSDeclarationBlock TOOL_TIP_DIV = new CSSDeclarationBlock(
			DARK_GRAY_BORDER, COLOR, "black", DISPLAY, "none",
			BACKGROUND_COLOR, LIGHT_GRAY.getHTMLColorCode(), OPACITY, "0.8",
			FILTER, "alpha(opacity = 80)");

	/** Style for tool-tip captions. */
	public static final CSSDeclarationBlock TOOL_TIP_CAPTION = new CSSDeclarationBlock(
			DARK_GRAY_BORDER, COLOR, "white", BACKGROUND_COLOR, DARK_GRAY
					.getHTMLColorCode()).inheritFrom(SMALL_FONT);

	/** Style for tool-tip cells. */
	public static final CSSDeclarationBlock TOOL_TIP_CELL = new CSSDeclarationBlock(
			SMALL_FONT, COLOR, "black", BACKGROUND_COLOR, LIGHT_GRAY
					.getHTMLColorCode());

	/** Blue background. */
	public static final CSSDeclarationBlock BLUE_BACKGROUND = new CSSDeclarationBlock(
			BACKGROUND_COLOR, ECCSMColor.BLUE.getHTMLColorCode(), COLOR,
			"white");

	/** Light blue background. */
	public static final CSSDeclarationBlock LIGHT_BLUE_BACKGROUND = new CSSDeclarationBlock(
			BACKGROUND_COLOR, ECCSMColor.LIGHT_BLUE.getHTMLColorCode());

	/** White background. */
	public static final CSSDeclarationBlock WHITE_BACKGROUND = new CSSDeclarationBlock(
			BACKGROUND_COLOR, "white");

	/** Blue background, no margin. */
	public static final CSSDeclarationBlock BLUE_BODY = new CSSDeclarationBlock(
			DEFAULT_FONT).inheritFrom(BLUE_BACKGROUND).setMargin("0px");

	/** Zero padding, zero margin. */
	public static CSSDeclarationBlock DEFAULT_CONTAINER = new CSSDeclarationBlock(
			DEFAULT_FONT).setMargin("0px").setPadding("0px");

	/** CSS for inlined image. */
	public static CSSDeclarationBlock INLINED_IMAGE = new CSSDeclarationBlock(
			DISPLAY, "inline", VERTICAL_ALIGN, "text-bottom")
			.setBorderWidth("0px");

	/** CSS for link cursor. */
	public static final CSSDeclarationBlock LINK_CURSOR = new CSSDeclarationBlock(
			CURSOR, "pointer");

	public static final CSSDeclarationBlock CODE = new CSSDeclarationBlock(
			COLOR, "black", BACKGROUND_COLOR, "#f9f9f9", LINE_HEIGHT, "1.1em")
			.setPadding("1em").setBorder("1px", "dashed",
					ECCSMColor.BLUE.getHTMLColorCode());

	/** Create and register all CSS blocks used. */
	private CSSMananger() {
		addDefaultDeclaration(IMG, new CSSDeclarationBlock()
				.setBorderWidth("0px"));

		addDefaultDeclaration(A, new CSSDeclarationBlock(DEFAULT_FONT,
				FONT_SIZE, "12px", FONT_WEIGHT, "600", COLOR, "black",
				TEXT_DECORATION, "none"));

		addDefaultDeclaration(A, ECSSPseudoClass.HOVER,
				new CSSDeclarationBlock(TEXT_DECORATION, "underline"));

	}

	/** The singleton instance. */
	private static CSSMananger instance;

	/** Get singleton instance. */
	public static CSSMananger getInstance() {
		if (instance == null) {
			instance = new CSSMananger();
		}
		return instance;
	}

	/**
	 * Write style file to disk.
	 * 
	 * @throws ConQATException
	 *             if style file could not be written.
	 */
	/* package *//*
					 * void write(File outputDirectory) throws ConQATException {
					 * File file = new File(outputDirectory, "css/style.css");
					 * try { FileSystemUtils.ensureParentDirectoryExists(file);
					 * PrintStream stream = new PrintStream(file);
					 * writeOut(stream); stream.close(); } catch (IOException
					 * ex) { throw new ConQATException("Could not write style
					 * file: " + file); } }
					 */
}
